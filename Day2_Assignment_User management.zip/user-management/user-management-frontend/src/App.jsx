import React, { useState } from 'react';
import UserList from './components/UserList';
import UserForm from './components/UserForm';

const App = () => {
    const [users, setUsers] = useState([]);

    const addUser = (user) => {
        setUsers((prevUsers) => [...prevUsers, user]);
    };

    return (
        <div>
            <h1>User Management System</h1>
            <UserForm onAddUser={addUser} />
            <UserList users={users} />
        </div>
    );
};

export default App;
