import React from "react";

const Home = () => {
  return (
    <div className="container home mt-5">
      <h1>Welcome to the Task Management App</h1>
    </div>
  );
};

export default Home;